# Cobblemon Classic Water GEN1/2 Pack<br>
With this small resource pack the water is changed into a<br>
Pokémon GEN1/2 style water.<br>
The water is animated.

### **Info**<br>
The textures are from the Pokémon games Red/Blue/Green/Yellow(GB(C)) Version<br> 
& Gold/Silver/Crystal Version (GBC).<br> 

## **Optional Dependecies**<br>
- **[Cobblemon](https://www.curseforge.com/minecraft/mc-mods/cobblemon)**<br>
  
### **To-do**<br>
- _Polish textures (give the water a blinking effect)_<br>

## **Credits**<br>
_I did not create or do not own any of these textures/graphics!_<br>
_I used & modified the textures/graphics._<br> 

**All credit goes to the rightful owners/creators.**<br>

_**According to Bulbapedia "The graphics used in the games (RGBY)(GSC), are made by:<br> 
Satoshi Tajiri, Koji Nishino, Kenji Matsushima, Fumihiro Nonomura, Ryousuke Taniguchi."**_<br>

**Game Design + Map Design:**<br>
**[Satoshi Tajiri](https://bulbapedia.bulbagarden.net/wiki/Satoshi_Tajiri)**<br>

**Map Design:**<br>
**[Kōji Nishino](https://bulbapedia.bulbagarden.net/wiki/K%C5%8Dji_Nishino)**<br>
**[Kenji Matsusima](https://bulbapedia.bulbagarden.net/wiki/Kenji_Matsushima)**<br>
**[Fumihiro Nonomura](https://www.imdb.com/name/nm6227937/)**<br>
**[Ryohsuke Taniguchi](https://www.imdb.com/name/nm6227936/)**<br>

**Developers & Publishers:**<br>
**[Game Freak, Inc.](https://bulbapedia.bulbagarden.net/wiki/Game_Freak)**<br>
**[The Pokémon Company](https://bulbapedia.bulbagarden.net/wiki/<br>The_Pok%C3%A9mon_Company)**<br>
**[Nintendo](https://bulbapedia.bulbagarden.net/wiki/Nintendo)**<br>

## **Contact**
_**My Discord: WizzStar**_<br>
_You can contact me for issues, but also requests and/or ideas are welcome._